---
name: agentbot-fa-knowledge
slug: agentbot-fa-knowledge
description: |
  FlexiAgent customer support knowledge base. Contains all verified product facts,
  agent roster (Max, Bee, Iris, Remy, Vince, Cleo, Spark, Sheena, Atlas), pricing,
  webinar details, bonuses, replay policy, FAQ, social proof, and escalation contacts
  for FlexiAgent (flexiagent.flexifunnels.com). Read this skill before answering any
  customer question. Trigger: "what is FlexiAgent", "how much does it cost", "what does
  Max do", "will there be a replay", "how do I register", "what bonuses do I get".
license: Apache 2.0
version: 1.0.0
author: FlexiAgent Team
tags: [support, knowledge-base, flexiagent, faq, product-info]
metadata:
  openclaw:
    requires:
      env: []
      bins: []
    primaryEnv: ""
    emoji: "📚"
---

# FlexiAgent — Customer Support Knowledge Base

> Read this before answering any customer question. Use the index below to jump to the right section.

## Index

| Customer asks about | Section |
|---------------------|---------|
| What is FlexiAgent / how it works | 1 — Product Overview |
| A specific agent (Max, Bee, Iris...) | 2 — Agent Roster |
| Webinar date, time, agenda, joining | 3 — Webinar Details |
| Price, trial, monthly vs lifetime | 4 — Pricing |
| Bonuses, 30-Prompt Pack, 1:1 call | 5 — Live Attendee Bonuses |
| Replay, recording, missed webinar | 6 — Replay Policy |
| Technical setup, coding, devices | 7 — Technical Requirements |
| Who this is for | 8 — Target Audience |
| Problems it solves | 9 — Problems Solved |
| Testimonials, proof, is it real? | 10 — Social Proof |
| Guarantee | 11 — Guarantee |
| How to register, contact, seat limit | 12 — Registration & Contact |
| Common FAQs | 13 — Pre-Answered FAQ |

---

## 1. PRODUCT OVERVIEW

**Product Name:** FlexiAgent
**Tagline:** "Watch your business get a 62-employee AI team in 60 minutes"
**Built by:** FlexiFunnels team (Karthik R., Founder & Engineer)
**Development time:** 18 months
**Current traction:** 24 founding users live, 1,488+ active agent instances

### What it is
FlexiAgent is an AI agent platform that gives a business 62 specialized AI agents across 12 departments: ads, email, WhatsApp, customer support, video, podcasts, copywriting, analytics, payments, planning, and more.

### Key differentiators
- **Not generic AI.** Each agent has a defined role, defined refusal patterns, and integrates with real business data (Stripe, Meta, Email, WhatsApp).
- **60-second setup.** SSO login → first agent firing in 60 seconds.
- **Plain English only.** No coding, no prompt engineering.
- **Refusal patterns.** Agents decline unsafe or off-policy actions. Iris refuses to draft replies to legal threats. Remy applies refund policy without exception.

---

## 2. AGENT ROSTER

### The Lead Nine

| Agent | Role | Key capability |
|-------|------|----------------|
| **Max** | Paid Ads Commander | Daily ad standup — surfaces kill/scale decisions. Saved ₹240/day killing a losing adset on Day 2. Integrates with Meta Ads. |
| **Bee** | Chief of Staff | Daily CEO digest from Stripe + Meta + Email. Turns 2 hrs of Monday dashboarding into a 4-min email at 8 AM. |
| **Iris** | Support & Comms Guard | Triages inbox, drafts replies, escalations. Refusal: won't draft replies to legal threats. Triaged 28 emails before one founder woke up. |
| **Remy** | Payments & Refunds | Policy-based refund gating. Zero emotional decisions. Zero exceptions. |
| **Vince** | Video Producer | Multi-format video rendering. Renders 3 cuts in 6 minutes. |
| **Cleo** | Podcast & Course Producer | Audio content creation and course workflow automation. |
| **Spark** | Copy & Hooks | Copywriting, social hooks, platform-specific copy. |
| **Sheena** | Dashboards & Reporting | Data aggregation and cross-channel reporting. |
| **Atlas** | AI Concierge & Planner | Planning, scheduling, task orchestration. |

**+ 53 more agents** across 12 departments — full roster revealed at webinar (00:38–00:48).

---

## 3. WEBINAR DETAILS

| Detail | Value |
|--------|-------|
| **Date** | Saturday, June 7 |
| **Time** | 3:00 PM IST |
| **Duration** | 60 minutes |
| **Cost** | Free |
| **Total seats** | 1,000 (live counter on page — check page for current availability) |
| **Host** | Karthik R., Founder & Engineer |
| **Registration URL** | https://flexiagent.flexifunnels.com/launch/ |

### Agenda

| Timestamp | Segment |
|-----------|---------|
| 00:00–00:05 | Welcome |
| 00:05–00:17 | Max Demo — paid ads standup (12 min) |
| 00:17–00:25 | Bee Demo — CEO digest (8 min) |
| 00:25–00:38 | Magic Moment — 5 agents in parallel: Iris, Vince, Remy (13 min) |
| 00:38–00:48 | Team Overview — all 62 agents, 12 departments (10 min) |
| 00:48–00:53 | Setup — SSO walkthrough (5 min) |
| 00:53–01:00 | Live Q&A + Offer — bonuses unlocked (7 min) |

**Pitch:** ~5 min at the end. First 55 min are demos + Q&A. Disclosed on registration page.

---

## 4. PRICING

| Plan | Price | Notes |
|------|-------|-------|
| **7-Day Free Trial** | ₹0 | Live attendees get 7 days; standard is 3 days |
| **Founding-300 Lifetime** | Revealed at webinar only | First 300 post-webinar upgrades; locked for life. Public price after launch = 2× founding rate. |
| **Post-Trial** | Pay only after trial | No auto-charge during trial |

### Rules
- NEVER quote a specific lifetime price — announced at the webinar only.
- Founding rate: capped at first 300 upgrades after the webinar.
- No charges during the 7-day trial.

---

## 5. LIVE ATTENDEE BONUSES

**Total: ₹13,300 — all exclusive to live attendees only.**

| Bonus | Value | What it is |
|-------|-------|-----------|
| **7-Day Full-Access Trial** | ₹4,900 | 7 days instead of standard 3 |
| **The 30-Prompt Pack** | ₹2,400 | 30 copy-paste prompts for instant agent magic moments |
| **1:1 Setup Call** | ₹6,000 | 30-min Zoom to wire first 3 agents |
| **Founding-300 Lifetime Pricing** | Priceless | Locked rate for first 300 post-webinar upgrades |

Registrants who don't attend live do NOT receive any of these bonuses.

---

## 6. REPLAY POLICY

- **Full replay:** NOT available. Q&A + offer + bonuses are live-only.
- **Short highlight:** 20-minute cut sent to all registrants.
- **Missed it?** Contact WhatsApp +91 93689 22458 for future event info.

---

## 7. TECHNICAL REQUIREMENTS

- No coding. No prompt engineering. Plain English only.
- Web-based — any browser, any device.
- Setup: 60 seconds from SSO to first agent.
- Integration needs: Max → Meta Ads; Bee → Stripe + Meta + Email; Iris → email inbox.

---

## 8. TARGET AUDIENCE

Best fit: FlexiFunnels customers, founders, course creators, coaches, agency owners, e-commerce operators.
Less ideal: large enterprises needing on-premise infrastructure.

---

## 9. PROBLEMS SOLVED

| Pain | Fix |
|------|-----|
| 2 hrs dashboard-flipping every Monday | Bee → 4-min digest at 8 AM |
| Losing adsets burning ₹3k–₹15k/week | Max → kill/scale decisions daily |
| 28 emails + inbox dread by 9 AM | Iris → triages before you wake |
| Emotional, inconsistent refunds | Remy → policy-only, zero exceptions |
| Video edits delayed 3+ days | Vince → 3 cuts in 6 min |
| No cross-channel ROAS visibility | Bee → ROAS + NPS + all channels |

---

## 10. SOCIAL PROOF

- 24 founders live, 1,488+ agent instances, 18 months of development
- Week-1: +6 hrs/week saved; Max killed loser on Day 2 → ₹240/day saved

**Testimonials (use exact text):**
- *"Max killed a $60/day adset I'd been ignoring for 9 days. That alone paid for FlexiAgent for the year."* — Rohit S., Course creator, Bengaluru
- *"Monday mornings used to be 2 hours of dashboard-flipping. Now Bee sends one email at 8 AM."* — Preeti M., Coach, Mumbai
- *"The refusal patterns are the magic. Iris won't draft replies to legal threats."* — Anand K., Agency, Chennai

---

## 11. GUARANTEE

> "If you don't see one 'wait, what?' moment in the first 15 minutes… I'll send you the 30-Prompt Pack anyway. No questions asked. No follow-up. No upsell." — Karthik R., Founder

Content guarantee for the free webinar only. 30-Prompt Pack is sent regardless.

---

## 12. REGISTRATION & CONTACT

| Item | Detail |
|------|--------|
| **Registration page** | https://flexiagent.flexifunnels.com/launch/ |
| **CTA** | "Save my seat" |
| **Calendar** | Google, Apple, Outlook (.ics) |
| **Seat limit** | 1,000 — live counter, closes when full |
| **WhatsApp support** | +91 93689 22458 |
| **Founding cap** | First 300 post-webinar upgrades only |

---

## 13. PRE-ANSWERED FAQ

**Q: How do I register?**
Go to https://flexiagent.flexifunnels.com/launch/ → "Save my seat" → fill the form → get confirmation with webinar link.

**Q: Is it free?**
Yes. Webinar is free. You pay only if you keep FlexiAgent after the 7-day trial.

**Q: Are seats still available?**
Check the live counter on the registration page.

**Q: Can non-FlexiFunnels customers attend?**
Yes. Some agents will have limited integration depth outside FlexiFunnels. Escalate specifics to WhatsApp +91 93689 22458.

**Q: How much does it cost?**
Trial is free (7 days for live attendees). Exact price revealed at the webinar. Founding-300 rate = 2× cheaper than future public price.

**Q: Monthly or lifetime only?**
Both will exist — announced at webinar. Lifetime is Founding-300 only (first 300 upgrades).

**Q: What happens after trial?**
Pay to continue or cancel — no auto-charge.

**Q: What does Max do?**
Monitors Meta ad campaigns daily, surfaces kill/scale decisions. Saved ₹240/day for one user on Day 2.

**Q: How many agents?**
62 across 12 departments.

**Q: Do I need coding skills?**
No. Plain English only. Agents are pre-configured.

**Q: Will there be a replay?**
20-min highlight only. Full webinar (Q&A, offer, bonuses) is live-only.

**Q: What if I can't attend 3 PM IST?**
Register to get the 20-min highlight. Contact +91 93689 22458 for future events.

**Q: When do I get the 1:1 setup call?**
After the webinar, for live attendees who upgrade. 30-min Zoom to wire first 3 agents.

**Q: What is the 30-Prompt Pack?**
30 copy-paste prompts for instant agent magic moments. Value: ₹2,400.

**Q: Can I get bonuses without attending live?**
No. All four bonuses are live-attendee-only without exception.
